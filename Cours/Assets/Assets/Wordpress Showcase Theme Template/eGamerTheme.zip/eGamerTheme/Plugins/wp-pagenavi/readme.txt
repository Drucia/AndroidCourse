=== WP-PageNavi ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: pagenavi, navi, navigation, wp-pagenavi, page
Requires at least: 2.5.0
Stable tag: 2.31

Adds a more advanced paging navigation your WordPress blog.

== Description ==

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-PageNavi Readme](http://lesterchan.net/wordpress/readme/wp-pagenavi.html "WP-PageNavi Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-PageNavi Readme](http://lesterchan.net/wordpress/readme/wp-pagenavi.html "WP-PageNavi Readme") (Installation Tab)

== Screenshots ==

[WP-PageNavi Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-pagenavi/ "WP-PageNavi Screenshots")

== Frequently Asked Questions ==

[WP-PageNavi Support Forums](http://forums.lesterchan.net/index.php?board=14.0 "WP-PageNavi Support Forums")