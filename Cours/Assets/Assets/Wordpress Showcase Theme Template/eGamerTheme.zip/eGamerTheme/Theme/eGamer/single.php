﻿<?php get_header(); ?>	
<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
<div id="container">
	
<div id="left-div">
		
<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>


<span class="single-entry-titles" style="margin-top: 18px;">Posted by <?php the_author() ?> on  <?php the_time('F j, Y') ?></span>
<div class="post-wrapper">
<div style="clear: both;"></div>
<?php if (get_option('artsee_thumbnails') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
<h1 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="post-info">Categories:  <?php the_category(', ') ?>  | <a href="#postcomment" title="<?php _e("Leave a comment"); ?>"><?php comments_number('no responses','one response','% responses'); ?></a></div>

<?php $rating = get_post_meta($post->ID, 'rating_value', $single = true); ?>
<?php if($rating !== '') { ?>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/star-large-<?php echo $rating; ?>.gif" alt="Post Rating" />
<?php } else { echo ''; } ?>

<?php the_content(); ?>
</div>


<?php $video = get_post_meta($post->ID, 'Video', $single = true); ?>
<?php 
if($video !== '') { ?>
<span class="single-entry-titles" style="margin-top: 18px;">Play Video</span>
<div class="post-wrapper" style="padding-top: 14px;">
<?php echo $video; ?>
</div>
<?php }
else { echo ''; } ?>


<span class="single-entry-titles" style="margin-top: 18px;">Post a Comment</span>
<div class="post-wrapper">
<div style="clear: both;"></div>
<?php comments_template(); ?>
</div>


<?php endwhile; ?>
<?php endif; ?>			
	
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?> 
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->
	
</body>
</html>