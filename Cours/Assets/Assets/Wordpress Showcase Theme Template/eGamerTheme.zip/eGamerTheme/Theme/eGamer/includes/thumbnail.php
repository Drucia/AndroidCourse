﻿		<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'image_value', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'image_value Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'image_value Alt', $single = true);
				 ?>
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=250&amp;w=250&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  style="border: 10px solid #333E3C; float: left; display: inline; margin-right: 10px;" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>