﻿<div id="categories">
<ul><?php wp_list_cats("sort_column=$artsee_sort_cat&sort_order=$artsee_order_cat&optioncount=0&depth=1&exclude=$artsee_exclude_cat"); ?></ul>
</div>