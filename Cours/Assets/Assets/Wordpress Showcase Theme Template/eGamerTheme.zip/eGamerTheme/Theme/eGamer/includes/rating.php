﻿<!--Begind recent Video-->
<div class="home-post-wrap">	
<span class="home-post-titles">
<span style="float: left;">Recent Reviews</span>
</span> 
<?php
 $querystr = "
    SELECT wposts.* 
    FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta
    WHERE wposts.ID = wpostmeta.post_id 
    AND wpostmeta.meta_key = 'rating_value' 
    AND wposts.post_status = 'publish' 
    AND wposts.post_type = 'post' 
    ORDER BY wposts.post_date DESC
 ";
 $pageposts = $wpdb->get_results($querystr, OBJECT);
  ?>
 <?php if ($pageposts): ?>
 <?php foreach ($pageposts as $post): ?>
 <?php setup_postdata($post); ?>
 
 <?php static $ctr = 0; 
if ($ctr == "4") { break; } 
else { ?>
<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'image_value', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'image_value Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'image_value Alt', $single = true);
?>
<div class="post-inside-small">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=43&amp;w=43&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="thumbnail-small" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>" style="float: left;"><?php the_title2('', '...', true, '26') ?></a>
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/star-<?php echo get_post_meta($post->ID, "rating_value", true); ?>.gif" alt="rating" style="float: right;" />
<span class="post-info-small">Posted by <?php the_author() ?> on  <?php the_time('m jS, Y') ?></span>
</div>
<div style="clear: both;"></div>
<?php $ctr++; } ?>
 <?php endforeach; ?>
 <?php endif; ?>
 </div>
<!--end recent Video-->