﻿<div class="sidebar-box">
<h3 style="margin-bottom: 10px;">we recommend</h3>
<div style="margin-left: 0px; width: 266px; padding-left: 6px;">
<a href="<?php echo $artsee_banner_url_one; ?>"><img src="<?php echo $artsee_banner_image_one; ?>" style="border: none; float: left; margin: 2px;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_two; ?>"><img src="<?php echo $artsee_banner_image_two; ?>" style="border: none; float: left; margin: 2px;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_three; ?>"><img src="<?php echo $artsee_banner_image_three; ?>" style="border: none; float: left; margin: 2px;" alt="advertisement" /></a>
<a href="<?php echo $artsee_banner_url_four; ?>"><img src="<?php echo $artsee_banner_image_four; ?>" style="border: none; float: left; margin: 2px;" alt="advertisement" /></a>
</div>
</div>