﻿<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/scrollTo.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/serialScroll.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/init.js"></script>