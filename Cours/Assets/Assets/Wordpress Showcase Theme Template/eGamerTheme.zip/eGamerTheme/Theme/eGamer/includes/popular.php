﻿<!--Begind Popular Articles-->
<div class="home-post-wrap-2">	
<span class="home-post-titles">
<span style="float: left;">Popular Articles</span>
</span> 
<div class="post-inside-small">
<ul class="list2">
<?php
	$sql='SELECT post_title, comment_count, guid
		FROM wp_posts
		ORDER BY comment_count DESC
		LIMIT 10;';
	$results = $wpdb->get_results($sql);

	foreach ($results as $r) {
		echo '<li><a href="' . $r->guid . '" title="' . $r->post_title . '"> ' . $r->post_title .
			' (' . $r->comment_count . ')</a></li>';
	}
?>
</ul>
</div>
 </div>
<!--end Popular Articles-->

<!--Begind Random Articles-->
<div class="home-post-wrap-2">	
<span class="home-post-titles">
<span style="float: left;">Random Articles</span>
</span> 
<div class="post-inside-small">
<ul>
 <?php $my_query = new WP_Query('orderby=rand&showposts=10');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '', true, '400') ?></a></li>
<?php endwhile; ?>
</ul>
</div>
 </div>
<!--end Random Articles-->