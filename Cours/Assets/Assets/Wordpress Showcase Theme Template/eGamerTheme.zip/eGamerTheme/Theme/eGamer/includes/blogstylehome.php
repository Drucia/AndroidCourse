﻿<div style="position: relative;">
<div class="prev"></div>
<div class="next"></div>
</div>
<div id="sections">
<ul>
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=3");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<li class="thumbnail-div-featured" style="background-image: url(<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "image_value", true); ?>&amp;h=253&amp;w=619&amp;zc=1&amp;q=50);">
<div class="featured-inside">
<span class="post-info">Posted by <?php the_author() ?> on  <?php the_time('F j, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></span>
<a href="<?php the_permalink() ?>" rel="bookmark" class="titles-featured" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '36') ?></a>
<?php the_content_limit(200, ""); ?>
</div>
</li>
<?php endwhile; ?>
</ul>
</div>

 <?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<!--Begin Post-->
<span class="single-entry-titles" style="margin-top: 18px;"></span>
<div class="post-wrapper">
<div style="clear: both;"></div>
<?php if (get_option('artsee_thumbnails') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/thumbnail.php'); } ?>
<h2 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('F j, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
			

<?php the_content(); ?>
</div>
<?php endwhile; ?>

<!--End Post-->


<div style="clear: both;"></div>

<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } 
else { ?>
<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>
<?php } ?>

<?php else : ?>

<h2 >No Results Found</h2>

<p>Sorry, your search returned zero results. </p>

<?php endif; ?>