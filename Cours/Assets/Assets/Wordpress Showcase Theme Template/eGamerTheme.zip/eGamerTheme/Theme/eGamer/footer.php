<div style="clear: both;"></div>
</div>
</div>
<div id="footer">
<div style="width: 915px; padding-left: 25px; margin-left: auto; margin-right: auto; display: block;">
&copy; Copyright <?php bloginfo('name'); ?> 2008. All rights reserved. | Powered by <a href="http://www.wordpress.org">Wordpress</a> | Designed by <a href="http://www.elegantthemes.com">Elegant Themes</a>
</div>
</div>

<?php wp_footer(); ?>