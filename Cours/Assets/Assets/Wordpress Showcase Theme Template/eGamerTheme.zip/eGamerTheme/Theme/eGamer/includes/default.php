﻿<div style="position: relative;">
<div class="prev"></div>
<div class="next"></div>
</div>
<div id="sections">
<ul>
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=$artsee_homepage_featured");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<li class="thumbnail-div-featured" style="background-image: url(<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo get_post_meta($post->ID, "image_value", true); ?>&amp;h=253&amp;w=619&amp;zc=1&amp;q=50);">
<div class="featured-inside">
<span class="post-info">Posted by <?php the_author() ?> on  <?php the_time('F j, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></span>
<a href="<?php the_permalink() ?>" rel="bookmark" class="titles-featured" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '36') ?></a>
<?php the_content_limit(200, ""); ?>
</div>
</li>
<?php endwhile; ?>
</ul>
</div>

<?php if (get_option('artsee_video') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/video.php'); } ?>

<?php if (get_option('artsee_rating') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/rating.php'); } ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>

<?php 
// check for thumbnail
$thumb = get_post_meta($post->ID, 'image_value', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'image_value Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'image_value Alt', $single = true);
?>
<div class="home-post-wrap">	
<div class="home-post-titles">
<h2><a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '36') ?></a></h2>
<span class="comments-bubble"><?php comments_popup_link('0', '1', '%'); ?></span>
</div>
<div class="post-inside">
<span class="post-info">Posted by <?php the_author() ?> on  <?php the_time('F j, Y') ?></span>
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=90&amp;w=90&amp;zc=1" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"  class="thumbnail" /></a>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
<?php the_content_limit(350, ""); ?>
<a href="<?php the_permalink() ?>" rel="bookmark" style="float: right;" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/readmore.gif" alt="Read More of <?php the_title(); ?>" style="border: none;" /></a>
</div>
</div>

<?php $ctr++; } ?>

<?php endwhile; ?>

<?php if (get_option('artsee_popular') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/popular.php'); } ?>

<?php else : ?>


<div class="home-post-wrap2">
<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>
</div>


<?php endif; ?>