﻿<?php get_header(); ?>	

<!--Begin Feaured Article-->
<?php if (get_option('artsee_featured') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/featured.php'); } ?>
<!--End Feaured Article-->

<div id="container">

<div class="home-box-container">
<span class="heading2">Random Posts</span>
<div class="prev"></div>
<div class="home-box">
<ul>
 <?php $my_query = new WP_Query('orderby=rand&showposts=6');
  while ($my_query->have_posts()) : $my_query->the_post();
   ?>
<li>
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>" class="titles-small"><?php the_title2('', '...', true, '20') ?></a>
<div class="post-info">Posted by <?php the_author() ?> on  <?php the_time('m jS, Y') ?></div>
<?php $thumb = get_post_meta($post->ID, 'Thumbnail', $single = true); ?>
<?php if($thumb !== '') { ?>
<a href="<?php the_permalink() ?>" title="Permanent Link to <?php the_title(); ?>"><img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=65&amp;w=65&amp;zc=1" alt="<?php the_title(); ?>"  class="thumbnail-small" /></a>
<?php } else { echo ''; } ?>

<?php the_content_limit(100, ""); ?>
</li>
<?php endwhile; ?>
</ul>
</div>
<div class="next"></div>
</div>

<div class="home-box-container2">
<span class="heading2">Recent Comments</span>
<div class="prev"></div>
<div class="home-box2 home-comments">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */ ?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments("15", 55, '', ''); } ?>
</div>
<div class="next"></div>
</div>

<div class="home-box-container3">
<span class="heading2">Lifestream</span>
<div class="prev"></div>
<div class="home-box3">
<?php lifestream(); ?>
</div>
<div class="next"></div>
</div>

<div style="clear: both;"></div>
<div id="left-div">
		
<div id="left-inside">
<?php if (get_option('artsee_format') == 'Blog Style') { ?>
<?php include(TEMPLATEPATH . '/includes/blogstyle.php'); ?>
<?php } else { include(TEMPLATEPATH . '/includes/default.php'); } ?>
</div>
		
</div>

<?php get_sidebar(); ?>    
<?php get_footer(); ?>   
	
</body>
</html>