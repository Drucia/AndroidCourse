﻿<div class="adwrap">
<a href="<?php echo $artsee_banner_twofifty_url; ?>"><img src="<?php echo $artsee_banner_twofifty_image; ?>" style="border: none;" alt="advertisement" /></a>
</div>