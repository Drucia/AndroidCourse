﻿<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>

<div id="featured-container">
<div class="prev"></div>
<div id="featured">
<ul>
<?php $my_query = new WP_Query("category_name=Featured Articles&showposts=$artsee_homepage_featured;");
while ($my_query->have_posts()) : $my_query->the_post(); ?>
<li>
<span class="titles-featured"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></span>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<div style="clear: both;"></div>
<?php the_content_limit(415, ""); ?>
</li>
<?php endwhile; ?>
</ul>
</div>
<div class="next"></div>
</div>