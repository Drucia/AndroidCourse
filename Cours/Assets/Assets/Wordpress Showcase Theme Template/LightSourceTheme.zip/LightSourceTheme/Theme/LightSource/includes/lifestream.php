﻿<div class="home-box-container3">
<span class="heading2">Lifestream</span>
<div style="clear: both;"></div>
<div class="prev"></div>
<div class="home-box3">
<?php lifestream(); ?>
</div>
<div class="next"></div>
</div>