<?php
$day = '';
if (count($events))
{
    $today = date('m d Y');
    $yesterday = date('m d Y', time()-86400);
    ?>
    <ul>
    <?php
    foreach ($events as $result)
    {
        $timestamp = $result->get_date();
        if ($today == date('m d Y', $timestamp)) $this_day = 'Today';
        else if ($yesterday == date('m d Y', $timestamp)) $this_day = 'Yesterday';
        else $this_day = ucfirst(htmlentities(date($day_format, $timestamp)));
        if ($day != $this_day)
        {
            ?>
<li><h2 class="lifestream_date"><?php echo $this_day; ?></h2></li>

            <?php
            $day = $this_day;
        }
        ?>
<li>
<img src="<?php echo $lifestream_path . '/images/' . $result->feed->get_constant('ID'); ?>.png" alt="<?php echo $result->feed->get_constant('ID'); ?> (feed #<?php echo $result->feed->id; ?>)" />
<?php echo date($hour_format, $timestamp); ?>
<?php echo $result->render($_); ?>
</li>
        <?php
    }
    ?>

    <?php
}
else
{
    ?>
<li><p class="lifestream"><?php _e('There are no events to show at this time.', 'lifestream'); ?></p></li>
    <?php
}
?>
</ul>