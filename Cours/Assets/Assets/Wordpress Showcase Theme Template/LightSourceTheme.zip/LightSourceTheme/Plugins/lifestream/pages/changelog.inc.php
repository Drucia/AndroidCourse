<h2><?php _e('LifeStream Change Log', 'lifestream'); ?></h2>

<pre>
<?php readfile(dirname(LIFESTREAM_PLUGIN_FILE) . '/CHANGES'); ?>
</pre>