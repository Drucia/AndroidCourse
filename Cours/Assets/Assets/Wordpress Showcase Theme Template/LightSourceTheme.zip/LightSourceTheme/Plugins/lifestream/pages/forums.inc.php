<h2><?php _e('LifeStream Support Forums', 'lifestream'); ?> <small>(<a href="http://www.ibegin.com/labs/forum/?CategoryID=5" target="_blank"><?php _e('Open in a new window', 'lifestream'); ?></a>)</small></h2>

<p><?php _e('You may direct questions, feedback, and problems to us by posting in the forums below.', 'lifestream'); ?></p>

<iframe style="width: 100%; height: 500px;" src="http://www.ibegin.com/labs/forum/?CategoryID=5"></iframe>
