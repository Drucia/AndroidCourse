﻿<?php get_header(); ?>	

<div id="container">

<div id="left-div">
		
<div id="left-inside">	
			
<div class="home-post-wrap">	
<div class="heading"><span style="font-size: 14px; font-weight: bold;">Recent Articles</span></div>	
	
 <?php if (have_posts()) : while (have_posts()) : the_post(); 
  if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

		<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
				 ?>

<!--Begin Post Single-->
<div class="post">
<div class="thumbnail-div">
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<img src="<?php echo $thumb; ?>" width="111px" height="111px" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"	/>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>
</div>	
<div class="home-post-content">
<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '35') ?></a></h2>
<span class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></span>
<?php the_content_limit(230, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
</div>
<?php endwhile; ?>
</div>
<!--End Post Single-->

<div style="clear: both;"></div>

<p class="pagination"><?php next_posts_link('&laquo; Previous Entries') ?> <?php previous_posts_link('Next Entries &raquo;') ?></p>

<?php else : ?>

<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>

<?php endif; ?>
			
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>    
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->

</body>
</html>