<?php get_header(); ?>	

<div id="container">
	
<div id="left-div">
		
<div id="left-inside">
 
<div style="font-size: 20px;">Sorry, the page your requested could not be found, or no longer exists. </div>			
			
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>
<!--End Footer-->

</body>
</html>