﻿<?php get_header(); ?>	

<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
	  
<div id="wrapper-home">

<!--Begin Featured Article-->
<div id="featured">
<div id="heading-featured"><span style="font-size: 14px; font-weight: bold;">Featured Articles</span></div>	
<?php $my_query = new WP_Query('category_name=Featured Articles&showposts=1');
while ($my_query->have_posts()) : $my_query->the_post();
$do_not_duplicate = $post->ID; ?>
<div id="thumbnail-div-featured"><a href="<?php the_permalink() ?>"><img height="186" width="367" style="border: none;" alt="featured article" src="<?php echo get_post_meta($post->ID, "Featured", true); ?>" /></a></div>
<div id="featured-content">
<h1 class="titles-featured"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h1>
<div class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></div>
<?php the_content_limit(400, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
<div style="clear: both;"></div>
<?php endwhile; ?>
</div>
<!--End Featured Article-->

<div id="left-div">
		
<div id="left-inside">
		
<div class="home-post-wrap">	
<div class="heading"><span style="font-size: 14px; font-weight: bold;">Recent Articles</span></div>	
	
<?php if (have_posts()) : while (have_posts()) : the_post(); 
if( $post->ID == $do_not_duplicate ) continue; update_post_caches($posts); ?>

<?php static $ctr = 0; 
if ($ctr == "$artsee_homepage_posts;") { break; } 
else { ?>
		
		<?php 
		// check for thumbnail
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
// check for thumbnail class
$thumb_class = get_post_meta($post->ID, 'Thumbnail Class', $single = true);
// check for thumbnail alt text
$thumb_alt = get_post_meta($post->ID, 'Thumbnail Alt', $single = true);
				 ?>

<!--Begin Post Single-->
<div class="post">
<div class="thumbnail-div">
<?php // if there's a thumbnail
if($thumb !== '') { ?>

	<img src="<?php echo $thumb; ?>"
	width="111px" height="111px"
	alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>"
	/>

<?php } // end if statement

// if there's not a thumbnail

else { echo ''; } ?>
</div>			
<div class="home-post-content">
<h2 class="titles"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '35') ?></a></h2>
<span class="post-info">Posted by <?php the_author() ?> in  <?php the_category(', ') ?> on  <?php the_time('m jS, Y') ?> |  <?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?></span>
<?php the_content_limit(230, ""); ?>
<div class="readmore"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">Read More</a></div>
</div>
</div>
<?php $ctr++; } ?>
<?php endwhile; ?>
</div>
<!--End Post Single-->

<div style="clear: both;"></div>

<!--Begin Recent Posts-->
<div class="home-squares">
<div class="heading"><span style="font-size: 14px; font-weight: bold;">Recent Comments</span></div>
<div class="recent-comments">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(6, 60, '', ''); } ?>
</div>
</div>
<!--End Recent Posts-->

<!--Begin Random Posts-->
<div class="home-squares">
<div class="heading"><span style="font-size: 14px; font-weight: bold;">Random Articles</span></div>
<?php $my_query = new WP_Query('orderby=rand&showposts=3');
while ($my_query->have_posts()) : $my_query->the_post();
?>
<div class="random">
<div class="random-image">
<a href="<?php the_permalink() ?>"><img height="80px" width="70px" style="border: none;" alt="random article" src="<?php echo get_post_meta($post->ID, "Random", true); ?>" /></a>
</div>
<div class="random-content">
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '20') ?></a>
<?php the_content_limit(80, ""); ?>
</div>
</div>
<?php endwhile; ?>
</div>
<!--End Random Posts-->

<!--Begin About Us-->
<div class="home-post-wrap">	
<div class="heading"><span style="font-size: 14px; font-weight: bold;">About Us</span></div>	
<?php echo $artsee_about; ?>	
</div>
<!--End About Us-->

<?php else : ?>

<h2 >No Results Found</h2>
<p>Sorry, your search returned zero results. </p>

<?php endif; ?>
			
</div>
		
</div>

<!--Begin Sidebar-->
<?php get_sidebar(); ?>    
<!--End Sidebar-->

<!--Begin Footer-->
<?php get_footer(); ?>   
<!--End Footer-->
	
</body>
</html>