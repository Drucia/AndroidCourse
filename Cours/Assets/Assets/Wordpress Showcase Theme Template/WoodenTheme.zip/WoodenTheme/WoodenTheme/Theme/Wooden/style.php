<?php
require_once( dirname(__FILE__) . '../../../../wp-config.php');
require_once( dirname(__FILE__) . '/functions.php');
header("Content-type: text/css");

global $options;

foreach ($options as $value) {
    if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
?>

body {
margin: 0;
padding: 0;
color: #ABABAB;
background-color: #C78149;
background-image: url(images/bg.jpg);
background-position: top left;
font-family: <?php echo $artsee_body_font; ?>;
font-size: 11px;
line-height: 18px;
}

#bgdiv {
background-image: url(images/bg-2.jpg);
background-repeat: repeat-x;
background-position: top left;
width: 100%;
margin: 0px 0px 0px 0px;
padding: 0px 0px 0px 0px;
float: left;
}

#wrapper2 {
width: 950px;
margin-left: auto;
margin-right: auto;
padding: 0px 0px 0px 0px;
margin-top: 15px;
}

.post-wrapper {
background-color: #FFF;
padding: 15px;
width: 583px;
border: 1px solid <?php echo $artsee_content_border; ?>;
}

.home-post-content {
float: left;
width: 425px;
}

a:link { 
text-decoration: none; 
color: <?php echo $artsee_link_color; ?>; 
}

a:visited { 
text-decoration: none; 
color: <?php echo $artsee_link_color; ?>; 
}

a:hover, a:active { 
color: #3B3B3B; 
}


h1, h2, h3, h4, h5, h6 { 
font-weight: normal; 
margin: 0px 0 10px; 
}

h1 { 
font-size: 32px; 
margin-bottom: 0px; 
margin-top: 10px;
}

h2 { 
font-size: 28px; 
}

h3 { 
font-size: 24px;
}

.post-title {
line-height: 30px;
font-size: 24px;
}

.post {
margin-bottom: 20px;
float: left;
}

.heading {
background-image: url(images/heading-bg.gif);
border: 1px solid #4E0000;
padding-top: 6px;
height: 24px;
color: #FFF;
padding-left: 18px;
margin-bottom: 15px;
}

.home-post-wrap {
width: 593px;
padding: 10px;
margin-bottom: 10px;
float: left;
background-color: #FFF;
border: 1px solid <?php echo $artsee_content_border; ?>;
}

.readmore {
background-image: url(images/readmore.gif);
background-repeat: no-repeat;
background-position: left;
float: right;
padding-left: 20px;
margin-top: 5px;
}

.readmore a:link, .readmore a:hover {
color: #393939;
}
.thumbnail-home {
border: 0px;
margin: 0px 0px 0px 0px;
}

h4, h5, h6 { 
font-size: 20px; 
}

.titles { font-weight: normal; font-size: 24px; text-decoration: none;}
.titles a:link, .titles a:visited, .titles a:active {
text-decoration: none;
font-size: 20px;
font-weight: normal;
font-family: Trebuchet MS;
margin-bottom: 5px;
display: block;
}

#heading-featured {
background-image: url(images/heading-bg.gif);
border: 1px solid #4E0000;
padding-top: 6px;
height: 24px;
color: #FFF;
padding-left: 18px;
margin-bottom: 5px;
}

#featured {
width: 900px;
margin: 15px 15px 0px 15px;
background-color: #FFF;
border: 1px solid #ACC9D6;
float: left;
padding: 10px 10px 10px 10px;
}
#thumbnail-div-featured {
width: 400px;
height: 217px;
float: left;
background-image: url(images/featured-bg.gif);
padding-top: 33px;
padding-left: 36px;
}


#featured-content {
float: left;
width: 450px;
margin-left: 10px;
}

.titles-featured a, .titles-featured a:hover, .titles-featured {
font-size: 30px;
display: block;
margin-top: 10px;
line-height: 30px;
}

pre, blockquote {
overflow: auto;
padding: 0 10px;
margin: 20px 30px;
line-height: 1.8em;
background-color: #f5f5f5;
border: 1px solid #e0e0e0;
}

pre:hover, blockquote:hover {
background-color: #f0f0f0;
border: 1px solid #d0d0d0;
}

pre { 
padding-top: 10px; 
padding-bottom: 10px; 
}

code { 
color: #779900; 
font-family: Consolas, Verdana, "Courier New", Sans-Serif; 
}

ul, ol { 
line-height: 2.0em; 
}

ul { 
list-style-image: url(images/bullet.gif); 
}

#pages{
width: 950px;
margin-left: auto;
margin-right: auto;
}


#header {
width: 100%;
min-height: 59px;
background-image: url(images/header-bg.gif);
background-repeat: repeat-x;
background-color: #4F0000;
margin-left: auto;
margin-right: auto;
margin-top: 0px;
}

#wrapper-home {
float: left;
width: 950px;;
color: <?php echo $artsee_font_color; ?>;
background-image: url(images/content-bg.gif);
background-position: top;
background-repeat: repeat-x;
background-color: #FFF;
border: 4px solid #FFF;
padding-bottom: 15px;
}

#container{
float: left;
width: 950px;
color: <?php echo $artsee_font_color; ?>;
border: 4px solid #EDE6C5;
background-color: #FFF;
padding-bottom: 15px;
}

#left-div {
width: 650px;
float: left;
margin-top: 20px;
}

#left-inside{
float: left;
padding: 0px 0px 0px 19px;
}

#sidebar-wrapper {
width: 283px;
float: left;
margin-top: 20px;
margin-bottom: 20px;
}

#sidebar {
float: left;
width: 283px;
}

#footer {
clear: both;
width: 930px;
padding-left: 20px;
text-align: left;
color: #FFF;
padding-bottom: 10px;
padding-top: 18px;
margin-bottom: 20px;
margin: auto;
}

#footer a {
color: #FFF;
font-size: 11px;
}

#footer a:visited {
color: #FFF;
}
#footer a:hover {
color: #FFF;
text-decoration: underline;
}
#extras {
float: left;
width: 780px;
color: #C7AA92;
text-align: left;
padding: 0 10px 10px;
margin: 10px 12px 20px;
background-color: #f5f5f5;
border-top: 1px solid #e0e0e0;
border-bottom: 1px solid #e0e0e0;
}


#pages ul { 
list-style-type: none; 
list-style-image: none; 
float: left; 
margin-top: 15px; 
padding: 0px 0px 0px 0px; 
overflow: visible; 
}

#pages li:hover { 
background-color: #FFF; 
background-image: url(images/nav-right.gif); 
background-repeat: no-repeat; 
background-position: right; 
height: 27px;
}
#pages li { 
float: left; 
display: block; 
margin-right: 10px; 
margin-left: 10px; 
height: 27px;}

#pages li a:link,
#pages li a:visited {
float: left;
color: #FFF;
display: block;
padding-top: 3px;
font-size: 12px;
margin-bottom: 3px;
font-weight: bold;
padding-left: 5px;
padding-right: 5px;
height: 24px;
}

#pages li a:hover,
#pages li a:active {
color: #4D91AA;
font-size: 12px;
margin-bottom: 0px;
font-weight: bold;
background-image: url(images/nav-left.gif);
background-repeat: no-repeat;
background-position: left;
}


.sidebar-box {
padding-top: 5px;
margin-bottom: 0px;
}

.articleinfo {
border-bottom: 1px solid #EEEEEE; padding-bottom: 7px; color: #545454;
}

.sidebar-box ul li a:link, .sidebar-box ul li a:visited, .sidebar-box ul li a:active {
display: block; color: <?php echo $artsee_side_color; ?>; 
width: 100%; 
padding: 3px 3px 3px 3px; 
background-image: none !important;
} 

.sidebar-box ul li {
background-image: none !important;
background-color: #FFF !important;
color: #848484 !important;
}
.sidebar-box ul li:hover, .sidebar-box ul li a:hover {
background-image: none !important;
background-color: #FFF !important;
}

.sidebar-box ul li a:hover {
width: 100%;
display: block; 
color: <?php echo $artsee_side_hover_color; ?>; 
padding: 3px 3px 3px 3px;
} 

.sidebar-box h2 { 
margin-top: 5px; 
font-size: 12px; 
color: #FFF; 
padding-top: 4px; 
font-weight: normal; 
padding-bottom: 4px; 
text-transform: lowercase; 
margin-left: 0px; 
font-family: Verdana;
background-image: url(images/h3-bg.gif); 
background-repeat: no-repeat; 
height: 23px; 
padding-left: 10px;
}

#about {
float: left;
width: 250px;
margin-right: 20px;
}

#commentform {
margin: 1em 0;
background: #FFFFFF;
margin-left: 20px;
}

#commentform textarea {
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 370px;
}
#commentform textarea:hover {
background: #FFFFFF;
border: 1px solid #d6d3d3;
}
#commentform textarea:focus {
background: #ffffff;
border: 1px solid #939793;
}

#commentform #email {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-email.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform #author {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-author.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform #url {
font-size: 1.1em;
background: #f8f7f6;
border: 1px solid #d6d3d3;
width: 280px;
background-image: url(images/comment-website.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform #email:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-email.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform #author:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-author.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform #url:focus {
font-size: 1.1em;
background: #ffffff;
border: 1px solid #939793;
width: 280px;
background-image: url(images/comment-website.gif);
background-position: 7px 7px;
background-repeat: no-repeat;
height: 20px;
padding-left: 30px;
padding-top: 6px;
}
#commentform input{
margin-bottom: 3px;
}


.search_bg {
height:35px;
width:270px;
background:url(images/search-bg.gif) no-repeat left;
background-position: left;
margin-top: 0px;
float: right;
margin-bottom: 15px;
}

#search {
color:#FFFFFF;
padding:0;
}

#search input {
background: transparent;
border: none;
font-size:11px;
color:#3C3C3C;
font-family:Tahoma, arial, verdana, courier;
width:145px;
height:11px;
vertical-align:middle;
padding:10px;
}

.icons {
margin-top: 0px; 
margin-bottom: -5px;
margin-right: 10px;
}

#search .input {
width:71px;
height:35px;
background:none;
border:none;
vertical-align:middle;
margin:0;
padding:0;
margin-left: 25px;
}

.list2 {
color: <?php echo $artsee_font_color; ?>;
list-style-image: url(images/bullet.gif);
margin-top: 0px;
font-size: 11px;
}

.list2 a:hover{
color: <?php echo $artsee_side_hover_color; ?>;
list-style-image: url(images/bullet.gif);
margin-top: 0px;
font-size: 11px;
}

.list2 a {
color: <?php echo $artsee_font_color; ?>;
margin-top: 0px;
font-size: 11px;
}

.toptitle {
font-size: 20px;
color: <?php echo $artsee_link_color; ?>;
margin-left: 15px; 
display: block;
margin-top: 15px;
margin-bottom: 10px;
}
.toptitle2 {
font-size: 24px;
color: #FFF;
display: block;
margin-top: 15px;
margin-bottom: 10px;
}

.thumbnail-div {
width: 111px;
height: 111px;
margin-bottom: 10px;
float: left;
margin-right: 10px;
width: 126px;
height: 127px;
background-image: url(images/thumbnail-bg.gif);
padding-top: 10px;
padding-left: 18px;
}

.post-info {
margin-bottom: 10px;
color: #000;
font-size: 10px;
}

.thumbnail-div-featured {
border: 1px solid #E4E4E4;
width: 159px; 
height: 212px;
padding: 2px;
float: left;
}

.logo {
float: left; 
border: 0px;
margin-top: 15px;
}

a:focus {
outline: none;
}

#panel {
background: #F5F5ED;
height: 50px;
width: 300px;
display: none;
}

.slide {
margin: 0;
padding: 0;
background: url(images/dropdown-search.gif) no-repeat center top;
}

.btn-slide {
width: 69px;
height: 19px;
padding-left: 0px;
padding-top: 4px;
margin: 0 auto;
display: block;
font: normal 11px Verdana, Helvetica, sans-serif;
color: #fff !important;
text-decoration: none;
padding-left: 14px;
}

#search-wrap {
float: right;
width: 300px;
}

#panel2 {
border: 1px solid <?php echo $artsee_content_border; ?>;
width: 283px;
display: none;
}

.slide2 {
margin: 0px 0px 3px 0px;
padding: 0;
background: url(images/dropdown-about.gif) no-repeat center top;
}

.btn-slide2 {
width: 285px;
height: 18px;
padding-left: 0px;
padding-top: 6px;
margin: 0 auto;
display: block;
font: normal 11px Verdana, Helvetica, sans-serif;
color: #fff !important;
text-decoration: none;
padding-left: 14px;
}

#panel3 {
border: 1px solid <?php echo $artsee_content_border; ?>;
width: 283px;
display: none;
}

.slide3 {
margin: 0px 0px 3px 0px;
padding: 0;
background: url(images/dropdown-about.gif) no-repeat center top;
}

.btn-slide3 {
width: 285px;
height: 18px;
padding-left: 0px;
padding-top: 6px;
margin: 0 auto;
display: block;
font: normal 11px Verdana, Helvetica, sans-serif;
color: #fff !important;
text-decoration: none;
padding-left: 14px;
}

#panel4 {
border: 1px solid <?php echo $artsee_content_border; ?>;
width: 283px;
display: none;
}

.slide4 {
margin: 0px 0px 3px 0px;
padding: 0;
background: url(images/dropdown-about.gif) no-repeat center top;
}

.btn-slide4 {
width: 285px;
height: 18px;
padding-left: 0px;
padding-top: 6px;
margin: 0 auto;
display: block;
font: normal 11px Verdana, Helvetica, sans-serif;
color: #fff !important;
text-decoration: none;
padding-left: 14px;
}

.panel-inside {
padding-left: 10px;
padding-right: 10px;
display: block;
}

.share-div {
width: 590px;
height: 30px;
background-color: #FFF;
display: none;
}

.share {
visibility: <?php echo $artsee_share; ?>;
}
.random-image {
width: 44px;
height: 44px;
border: 4px solid #F2F2E4;
float: left;
margin-left: 10px;
}

.random-content {
float: right;
width: 210px;
}

.random-content a:link {
font-size: 13px;
}

.home-squares {
width: 280px;
display: block;
padding: 10px;
border: 1px solid #EBEBEB;
float: left;
margin-right: 12px;
margin-top: 10px;
margin-bottom: 10px;
min-height: 349px;
}

.random-image {
width: 70px;
height: 80px;
border: 5px solid #F8F4E0;
float: left;
}

.random-content {
float: right;
width: 190px;
}

.recent-comments ul {
list-style-image: url(images/icon-comments.gif);
}
.random {
width: 280px;
float: left;
margin-top: 10px;
}

/* Captions */
.aligncenter,
div.aligncenter {
	display: block;
	margin-left: auto;
	margin-right: auto;
}

.wp-caption {
	border: 1px solid #ddd;
	text-align: center;
	background-color: #f3f3f3;
	padding-top: 4px;
	margin: 10px;
	-moz-border-radius: 3px;
	-khtml-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}

.wp-caption img {
	margin: 0;
	padding: 0;
	border: 0 none;
}

.wp-caption p.wp-caption-text {
	font-size: 11px;
	line-height: 17px;
	padding: 0 4px 5px;
	margin: 0;
}
/* End captions */

/* Begin Images */
p img {
	padding: 0;
	max-width: 100%;
	}

/*	Using 'class="alignright"' on an image will (who would've
	thought?!) align the image to the right. And using 'class="centered',
	will of course center the image. This is much better than using
	align="center", being much more futureproof (and valid) */

img.centered {
	display: block;
	margin-left: auto;
	margin-right: auto;
	}

img.alignright {
	padding: 4px;
	margin: 0 0 2px 7px;
	display: inline;
	}

img.alignleft {
	padding: 4px;
	margin: 0 7px 2px 0;
	display: inline;
	}

.alignright {
	float: right;
	}

.alignleft {
	float: left
	}
/* End Images */

/* Begin Comments*/

.commentlist {
padding: 0px;
margin: 0px 0px 0px 17px;
width: 560px;
background-image: url(images/comment-bg.gif);
list-style-image: none;
list-style-type: none;
float: left;
}

.commentlist li {
	font-weight: bold;
	width: 560px;
	display: block;
	background-image: url(images/comment-bottom.gif);
	background-repeat: no-repeat;
	background-position: bottom left;
	padding: 0px 0px 45px 0px;
	margin: 0px;
	list-style-image: none;
	list-style-type: none;
	float: left;
	}

.commentlist li div {
	width: 540px;
	display: block;
	background-image: url(images/comment-top.gif);
	background-repeat: no-repeat;
	margin: 0px;
	padding: 10px;
	float: left;
}

.commentlist li .avatar { 
	float: left;
	border: 1px solid #eee;
	padding: 2px;
	background: #fff;
	}

.commentlist cite {
	font-size: 18px;
	float: left;
	font-style: normal;
	margin-left: 10px;
	margin-right: 6px;
	margin-top: 5px;
	font-weight: normal;
	}
	
.says {
display: none;
}

.commentlist p {
	font-weight: normal;
	line-height: 1.5em;
	text-transform: none;
	display: block;
	float: left;
	width: 90%;
	margin-left: 3%;
	}
	

#commentform p {
clear: both;
	}

.alt {
	margin: 0;
	padding: 10px;
	}

.nocomments {
	text-align: center;
	margin: 0;
	padding: 0;
	}

.commentlist .children li {
	width: 90%;
	display: block;
	margin: 0px;
	background-color: #FDFDFD;
	background-image: url(images/comment-children-bg.gif);
	background-position: left;
	background-repeat: repeat-y;
	border: 1px solid #E2E2E4;
	overflow: hidden;
}

.commentlist .children li div {
width: 97%;
padding: 3%;
background-image: url(images/comment-children-top.gif);
background-repeat: no-repeat;
background-position: top left;
}

.commentlist .commentmetadata {
	font-weight: normal;
	float: left;
	margin: 5px 0px 0px 0px;
	display: block;
	clear: both;
	background-image: none;
	width: 90%;
	margin-left: 3%;
	}
	
.commentlist .vcard, .commentlist .children .comment-author, .commentlist .children .vcard, .commentlist .commentmetadata, .commentlist .children .comment-author, .commentlist .children .comment-meta   {
	background-image: none;
	width: 100%;
	padding: 0px !important;
}

.commentlist .reply, .commentlist .children .reply {
	float: right;
	background-image: none;
	width: 54px;
	height: 22px;
	margin-bottom: 0px;
	padding: 0px;
	margin-right: 10px;
	font: 0.9em 'Lucida Grande', Verdana, Arial, Sans-Serif;
}

.commentlist .reply a:link, .commentlist .reply a:hover, .commentlist .children .reply a:link, .commentlist .children .reply a:hover {
	background-image: url(images/reply.gif);
	width: 39px;
	height: 17px;
	display: block;
	color: #FFF;
	font-size: 8px;
	text-transform: lowercase;
	font-weight: normal;
	padding: 5px 0px 0px 15px;
	letter-spacing: 1px;
}

.commentlist .children li {
padding-bottom: 10px;
}

.commentlist .children li ul li {
padding-bottom: 10px;
background-color: #FFF;
}

#respond {
margin-top: 20px;
float: left;
background-image: none;
}

.commentlist #respond h3, .commentlist #respond a {
margin-left: 28px;
}

#comments {
line-height: 30px;
}

.children {
clear: both;
}

.children .commentmetadata, .children .vcard  {
	background-image: none;
}

.children textarea {
width: 90% !important;
}

.children input {
width: 80% !important;
}

#cancel-comment-reply-link {
display: block;
background-image: url(images/comment-close.gif);
width: 144px;
height: 21px;
padding: 5px 0px 0px 23px;
font-weight: normal;
color: #84878E;
font: 1em 'Lucida Grande', Verdana, Arial, Sans-Serif;
}

#respond div {
background-image: none;
}

#submit {
width: 120px !important;
}

/* End Comments */